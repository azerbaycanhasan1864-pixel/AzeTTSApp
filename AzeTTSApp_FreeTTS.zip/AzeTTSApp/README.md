# 🎙️ AzəTTS — Pulsuz Azərbaycan Dilli PDF & Word Oxuyucu

Android-in **daxili TTS mühərriki** ilə PDF və Word fayllarını Azərbaycan dilində oxuyan tətbiq.

✅ Tamamilə **pulsuz** | ✅ **İnternet tələb etmir** | ✅ **API açarı lazım deyil**

---

## ⚙️ Quraşdırma (3 addım)

### 1. Android Studio-da açın
```
File → Open → AzeTTSApp qovluğunu seç → Gradle sync gözlə
```

### 2. Cihazda az-AZ dil paketini yükləyin (bir dəfəlik)
```
Telefon Parametrləri → Əlçatanlıq → Mətn-Səsə çevirmə → az-AZ → Yüklə
```
> az-AZ paketi yoxdursa tətbiq avtomatik **tr-TR** (Türk) ilə işləyir.

### 3. Quraşdırın və işə salın
```
Run ▶️ → Öz telefonunuzu seçin
```

---

## 📦 Asılılıqlar (avtomatik yüklənir)

| Kitabxana | Məqsəd |
|-----------|--------|
| `pdfbox-android:2.0.27.0` | PDF mətn çıxarma |
| `poi-ooxml:5.2.5` | DOCX (Word 2007+) |
| `poi:5.2.5` | DOC (Word 97-2003) |
| `material:1.12.0` | Material Design UI |

---

## 🐛 Tez-tez Xətalar

| Xəta | Həll |
|------|------|
| "az-AZ dil paketi yoxdur" | Telefon Parametrləri → TTS → az-AZ yüklə |
| "Faylda mətn tapılmadı" | PDF skan əsaslıdır — düz mətnli PDF istifadə edin |
| Səs çıxmır | Telefon səsini yoxlayın |
