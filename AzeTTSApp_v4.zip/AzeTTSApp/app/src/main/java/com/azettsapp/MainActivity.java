package com.azettsapp;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.slider.Slider;
import com.google.android.material.snackbar.Snackbar;

import java.io.InputStream;

public class MainActivity extends AppCompatActivity
        implements TextExtractorManager.ExtractionCallback,
                   AndroidTTSManager.TTSCallback {

    private static final int REQUEST_PICK_FILE = 1001;

    private TextView tvFileName, tvExtractedText, tvStatus, tvCurrentChunk;
    private LinearProgressIndicator progressBar;
    private MaterialButton btnPickFile;
    private ExtendedFloatingActionButton fabPlay;
    private ImageButton btnStop, btnRestart;
    private Slider sliderSpeed, sliderPitch;
    private TextView tvSpeedValue, tvPitchValue;
    private Chip chipLang;
    private View cardPlayer, rootView;

    private TextExtractorManager extractorManager;
    private AndroidTTSManager ttsManager;

    private String extractedText = "";
    private boolean isPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        initManagers();
        setupListeners();
    }

    private void initViews() {
        rootView        = findViewById(android.R.id.content);
        tvFileName      = findViewById(R.id.tv_file_name);
        tvExtractedText = findViewById(R.id.tv_extracted_text);
        tvStatus        = findViewById(R.id.tv_status);
        tvCurrentChunk  = findViewById(R.id.tv_current_word);
        progressBar     = findViewById(R.id.progress_bar);
        btnPickFile     = findViewById(R.id.btn_pick_file);
        fabPlay         = findViewById(R.id.fab_play);
        btnStop         = findViewById(R.id.btn_stop);
        btnRestart      = findViewById(R.id.btn_restart);
        sliderSpeed     = findViewById(R.id.slider_speed);
        sliderPitch     = findViewById(R.id.slider_pitch);
        tvSpeedValue    = findViewById(R.id.tv_speed_value);
        tvPitchValue    = findViewById(R.id.tv_pitch_value);
        chipLang        = findViewById(R.id.chip_azerbaijani);
        cardPlayer      = findViewById(R.id.card_player);
        setPlayerEnabled(false);
        tvStatus.setText("TTS başladılır...");
    }

    private void initManagers() {
        extractorManager = new TextExtractorManager(this, this);
        ttsManager       = new AndroidTTSManager(this, this);
    }

    private void setupListeners() {
        btnPickFile.setOnClickListener(v -> openFilePicker());

        fabPlay.setOnClickListener(v -> {
            if (isPlaying) pauseReading();
            else           startReading();
        });

        btnStop.setOnClickListener(v -> stopReading());

        btnRestart.setOnClickListener(v -> {
            ttsManager.stop();
            if (!extractedText.isEmpty()) startReading();
        });

        sliderSpeed.addOnChangeListener((slider, value, fromUser) -> {
            tvSpeedValue.setText(String.format("%.1fx", value));
            ttsManager.setSpeechRate(value);
        });

        sliderPitch.addOnChangeListener((slider, value, fromUser) -> {
            tvPitchValue.setText(String.format("%.1f", value));
            ttsManager.setPitch(value);
        });
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/pdf",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        });
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "PDF və ya Word seçin"), REQUEST_PICK_FILE);
    }

    @Override
    protected void onActivityResult(int req, int res, @Nullable Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQUEST_PICK_FILE && res == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) processFile(uri);
        }
    }

    private void processFile(Uri uri) {
        String name = getFileName(uri);
        tvFileName.setText(name);
        tvStatus.setText("Mətn çıxarılır...");
        progressBar.setVisibility(View.VISIBLE);
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            String mimeType = getContentResolver().getType(uri);
            extractorManager.extractText(is, mimeType, name);
        } catch (Exception e) {
            onExtractionError("Fayl açıla bilmədi: " + e.getMessage());
        }
    }

    private String getFileName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (col >= 0) name = c.getString(col);
                }
            }
        }
        if (name == null) name = uri.getLastPathSegment();
        return name != null ? name : "Naməlum fayl";
    }

    private void startReading() {
        if (extractedText.isEmpty()) {
            Toast.makeText(this, "Əvvəlcə fayl seçin", Toast.LENGTH_SHORT).show();
            return;
        }
        isPlaying = true;
        fabPlay.setIcon(ContextCompat.getDrawable(this, android.R.drawable.ic_media_pause));
        fabPlay.setText("Dayandır");
        ttsManager.speak(extractedText);
    }

    private void pauseReading() {
        isPlaying = false;
        fabPlay.setIcon(ContextCompat.getDrawable(this, android.R.drawable.ic_media_play));
        fabPlay.setText("Oxu");
        tvStatus.setText("Dayandırıldı ⏸");
        ttsManager.pause();
    }

    private void stopReading() {
        isPlaying = false;
        fabPlay.setIcon(ContextCompat.getDrawable(this, android.R.drawable.ic_media_play));
        fabPlay.setText("Oxu");
        tvStatus.setText("Dayandı ⏹");
        tvCurrentChunk.setText("");
        ttsManager.stop();
    }

    private void setPlayerEnabled(boolean enabled) {
        cardPlayer.setAlpha(enabled ? 1f : 0.45f);
        fabPlay.setEnabled(enabled);
        btnStop.setEnabled(enabled);
        btnRestart.setEnabled(enabled);
    }

    // ── ExtractionCallback ────────────────────────────────────────────────────

    @Override
    public void onExtractionSuccess(String text) {
        runOnUiThread(() -> {
            extractedText = text;
            progressBar.setVisibility(View.GONE);
            int wordCount = text.split("\\s+").length;
            String preview = text.length() > 400
                    ? text.substring(0, 400) + "…\n[" + wordCount + " söz]" : text;
            tvExtractedText.setText(preview);
            tvStatus.setText("✅ Hazır • " + wordCount + " söz");
            setPlayerEnabled(true);
            Snackbar.make(rootView, "Mətn uğurla çıxarıldı!", Snackbar.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onExtractionError(String error) {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);
            tvStatus.setText("❌ " + error);
            Toast.makeText(this, error, Toast.LENGTH_LONG).show();
        });
    }

    // ── AndroidTTSManager.TTSCallback ────────────────────────────────────────

    @Override
    public void onTTSReady(boolean success, String message) {
        runOnUiThread(() -> {
            if (success) {
                tvStatus.setText(message);
                chipLang.setText(message.contains("tr-TR") ? "🇹🇷 tr-TR" : "🇦🇿 az-AZ");
            } else {
                tvStatus.setText("⚠️ " + message);
                Snackbar.make(rootView, message, Snackbar.LENGTH_LONG)
                        .setAction("Parametrlər", v -> openTTSSettings())
                        .show();
            }
        });
    }

    @Override
    public void onSpeakingStarted() {
        runOnUiThread(() -> tvStatus.setText("🔊 Oxunur..."));
    }

    @Override
    public void onSpeakingProgress(int percent, String currentChunk) {
        runOnUiThread(() -> tvCurrentChunk.setText(
                currentChunk.length() > 80
                        ? currentChunk.substring(0, 80) + "..." : currentChunk));
    }

    @Override
    public void onSpeakingCompleted() {
        runOnUiThread(() -> {
            isPlaying = false;
            fabPlay.setIcon(ContextCompat.getDrawable(this, android.R.drawable.ic_media_play));
            fabPlay.setText("Oxu");
            tvStatus.setText("✅ Tamamlandı");
            tvCurrentChunk.setText("");
        });
    }

    @Override
    public void onSpeakingError(String error) {
        runOnUiThread(() -> {
            isPlaying = false;
            fabPlay.setIcon(ContextCompat.getDrawable(this, android.R.drawable.ic_media_play));
            fabPlay.setText("Oxu");
            tvStatus.setText("❌ " + error);
        });
    }

    private void openTTSSettings() {
        try {
            startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
        } catch (Exception e) {
            Toast.makeText(this, "Parametrlər → Əlçatanlıq → Mətn-Səsə çevirmə", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (ttsManager != null) ttsManager.shutdown();
        if (extractorManager != null) extractorManager.shutdown();
    }
}
