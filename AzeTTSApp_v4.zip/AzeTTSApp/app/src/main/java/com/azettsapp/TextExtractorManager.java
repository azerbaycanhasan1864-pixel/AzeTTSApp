package com.azettsapp;

import android.content.Context;
import android.util.Log;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PDF və Word (DOCX/DOC) fayllarından mətn çıxarır.
 *
 * Asılılıqlar (build.gradle):
 *   implementation 'org.apache.poi:poi:5.2.5'
 *   implementation 'org.apache.poi:poi-ooxml:5.2.5'
 *   implementation 'com.tom-roush:pdfbox-android:2.0.27.0'
 */
public class TextExtractorManager {

    private static final String TAG = "TextExtractor";

    public interface ExtractionCallback {
        void onExtractionSuccess(String text);
        void onExtractionError(String error);
    }

    private final Context context;
    private final ExtractionCallback callback;
    private final ExecutorService executor;

    public TextExtractorManager(Context context, ExtractionCallback callback) {
        this.context = context;
        this.callback = callback;
        this.executor = Executors.newSingleThreadExecutor();

        // PDFBox Android üçün resurs yükləyicisini başlat
        PDFBoxResourceLoader.init(context);
    }

    public void extractText(InputStream inputStream, String mimeType, String fileName) {
        executor.submit(() -> {
            try {
                String text;

                if (isPdf(mimeType, fileName)) {
                    text = extractFromPdf(inputStream);
                } else if (isDocx(mimeType, fileName)) {
                    text = extractFromDocx(inputStream);
                } else if (isDoc(mimeType, fileName)) {
                    text = extractFromDoc(inputStream);
                } else {
                    callback.onExtractionError("Dəstəklənməyən fayl növü: " + mimeType);
                    return;
                }

                String cleaned = cleanText(text);

                if (cleaned.isEmpty()) {
                    callback.onExtractionError("Faylda mətn tapılmadı. Şəkil əsaslı PDF ola bilər.");
                } else {
                    callback.onExtractionSuccess(cleaned);
                }

            } catch (Exception e) {
                Log.e(TAG, "Extraction error", e);
                callback.onExtractionError("Mətn çıxarıla bilmədi: " + e.getMessage());
            } finally {
                try { if (inputStream != null) inputStream.close(); }
                catch (Exception ignored) {}
            }
        });
    }

    // ── PDF ──────────────────────────────────────────────────────────────────

    private String extractFromPdf(InputStream is) throws Exception {
        try (PDDocument document = PDDocument.load(is)) {
            if (document.isEncrypted()) {
                throw new Exception("PDF şifrəlidir");
            }

            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            stripper.setLineSeparator("\n");
            stripper.setParagraphStart("\n");

            return stripper.getText(document);
        }
    }

    // ── DOCX (Word 2007+) ─────────────────────────────────────────────────────

    private String extractFromDocx(InputStream is) throws Exception {
        try (XWPFDocument document = new XWPFDocument(is)) {
            StringBuilder sb = new StringBuilder();

            for (XWPFParagraph paragraph : document.getParagraphs()) {
                String text = paragraph.getText();
                if (text != null && !text.trim().isEmpty()) {
                    sb.append(text).append("\n");
                }
            }

            // Cədvəllərdən mətn çıxar
            document.getTables().forEach(table ->
                table.getRows().forEach(row ->
                    row.getTableCells().forEach(cell -> {
                        String cellText = cell.getText();
                        if (cellText != null && !cellText.trim().isEmpty()) {
                            sb.append(cellText).append(" ");
                        }
                    })
                )
            );

            return sb.toString();
        }
    }

    // ── DOC (Word 97-2003) ────────────────────────────────────────────────────

    private String extractFromDoc(InputStream is) throws Exception {
        try (HWPFDocument document = new HWPFDocument(is)) {
            WordExtractor extractor = new WordExtractor(document);
            return extractor.getText();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String cleanText(String text) {
        if (text == null) return "";

        return text
                // Çoxsaylı boş sətirləri tək sətrə endir
                .replaceAll("\\n{3,}", "\n\n")
                // Çoxsaylı boşluqları tək boşluğa endir
                .replaceAll("[ \\t]{2,}", " ")
                // Xüsusi Unicode simvollarını təmizlə
                .replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]", "")
                // Tire variantlarını standart tire ilə əvəz et
                .replace("\u2013", "-")
                .replace("\u2014", "-")
                // Dırnaq işarəsi variantları
                .replace("\u201C", "\"")
                .replace("\u201D", "\"")
                .replace("\u2018", "'")
                .replace("\u2019", "'")
                .trim();
    }

    private boolean isPdf(String mimeType, String fileName) {
        return "application/pdf".equals(mimeType)
                || (fileName != null && fileName.toLowerCase().endsWith(".pdf"));
    }

    private boolean isDocx(String mimeType, String fileName) {
        return "application/vnd.openxmlformats-officedocument.wordprocessingml.document".equals(mimeType)
                || (fileName != null && fileName.toLowerCase().endsWith(".docx"));
    }

    private boolean isDoc(String mimeType, String fileName) {
        return "application/msword".equals(mimeType)
                || (fileName != null && fileName.toLowerCase().endsWith(".doc"));
    }

    public void shutdown() {
        executor.shutdown();
    }
}
