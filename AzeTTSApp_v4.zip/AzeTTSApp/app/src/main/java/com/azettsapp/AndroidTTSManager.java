package com.azettsapp;

import android.content.Context;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Android daxili TextToSpeech ilə Azərbaycan TTS.
 *
 * ✅ Tamamilə pulsuz
 * ✅ İnternet tələb etmir
 * ✅ Heç bir API açarı lazım deyil
 *
 * İstifadəçi telefonda az-AZ dil paketi yükləməlidirsə:
 *   Telefon Parametrləri → Əlçatanlıq → Mətn-Səs → az-AZ yüklə
 */
public class AndroidTTSManager implements TextToSpeech.OnInitListener {

    private static final String TAG = "AndroidTTS";
    private static final int CHUNK_SIZE = 400; // Android TTS max ~4000 char, biz az saxlayırıq

    public interface TTSCallback {
        void onTTSReady(boolean success, String message);
        void onSpeakingStarted();
        void onSpeakingProgress(int progressPercent, String currentChunk);
        void onSpeakingCompleted();
        void onSpeakingError(String error);
    }

    private final Context context;
    private final TTSCallback callback;
    private TextToSpeech tts;

    private List<String> chunks;
    private int currentIndex = 0;
    private boolean isStopped = false;
    private boolean isPaused = false;
    private boolean isInitialized = false;

    private float speechRate = 1.0f;
    private float pitch = 1.0f;

    public AndroidTTSManager(Context context, TTSCallback callback) {
        this.context = context;
        this.callback = callback;
        tts = new TextToSpeech(context, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            // Əvvəlcə Azərbaycan dilini sına
            int result = tts.setLanguage(new Locale("az", "AZ"));

            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // az-AZ yoxdursa, Türk dili ilə davam et (ən yaxın)
                Log.w(TAG, "az-AZ dil paketi yoxdur, tr-TR istifadə edilir");
                int trResult = tts.setLanguage(new Locale("tr", "TR"));

                if (trResult == TextToSpeech.LANG_MISSING_DATA
                        || trResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    callback.onTTSReady(false,
                            "Azərbaycan və Türk dili paketi tapılmadı.\n" +
                            "Telefon Parametrləri → Əlçatanlıq → Mətn-Səsə çevirmə → " +
                            "Dil paketlərini yönet → az-AZ yüklə");
                    return;
                }
                isInitialized = true;
                callback.onTTSReady(true,
                        "⚠️ az-AZ paketi yoxdur — tr-TR istifadə edilir.\n" +
                        "Daha yaxşı diksiyon üçün az-AZ paketini yükləyin.");
            } else {
                isInitialized = true;
                callback.onTTSReady(true, "✅ Azərbaycan TTS hazırdır");
            }

            setupProgressListener();

        } else {
            callback.onTTSReady(false, "TTS başladıla bilmədi. Cihazı yenidən başladın.");
        }
    }

    private void setupProgressListener() {
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                int idx = parseIndex(utteranceId);
                int percent = chunks != null
                        ? (int) ((idx * 100f) / chunks.size()) : 0;
                String chunk = (chunks != null && idx < chunks.size())
                        ? chunks.get(idx) : "";
                callback.onSpeakingProgress(percent, chunk);
            }

            @Override
            public void onDone(String utteranceId) {
                if (isStopped) return;
                currentIndex++;
                if (currentIndex >= (chunks != null ? chunks.size() : 0)) {
                    callback.onSpeakingCompleted();
                } else if (!isPaused) {
                    speakChunk(currentIndex);
                }
            }

            @Override
            public void onError(String utteranceId) {
                callback.onSpeakingError("Parça oxuna bilmədi: " + utteranceId);
            }
        });
    }

    public void speak(String text) {
        if (!isInitialized) {
            callback.onSpeakingError("TTS hələ hazır deyil");
            return;
        }
        isStopped = false;
        isPaused = false;
        chunks = splitText(text);
        currentIndex = 0;

        tts.setSpeechRate(speechRate);
        tts.setPitch(pitch);

        callback.onSpeakingStarted();
        speakChunk(0);
    }

    private void speakChunk(int index) {
        if (isStopped || isPaused || chunks == null || index >= chunks.size()) return;

        String chunk = chunks.get(index);
        String utteranceId = "chunk_" + index;

        Bundle params = new Bundle();
        params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM,
                android.media.AudioManager.STREAM_MUSIC);

        tts.speak(chunk, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
    }

    public void pause() {
        isPaused = true;
        tts.stop();
    }

    public void resume() {
        if (!isPaused) return;
        isPaused = false;
        speakChunk(currentIndex);
    }

    public void stop() {
        isStopped = true;
        isPaused = false;
        currentIndex = 0;
        tts.stop();
    }

    public void restart() {
        stop();
        if (chunks != null && !chunks.isEmpty()) {
            isStopped = false;
            speak(String.join(" ", chunks));
        }
    }

    public void setSpeechRate(float rate) {
        this.speechRate = rate;
        if (tts != null) tts.setSpeechRate(rate);
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
        if (tts != null) tts.setPitch(pitch);
    }

    public boolean isPlaying() {
        return tts != null && tts.isSpeaking();
    }

    public void shutdown() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private List<String> splitText(String text) {
        List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) return result;

        // Cümlə sərhədlərindən böl
        String[] sentences = text.split("(?<=[.!?\\n])\\s+");
        StringBuilder buffer = new StringBuilder();

        for (String sentence : sentences) {
            if (buffer.length() + sentence.length() > CHUNK_SIZE && buffer.length() > 0) {
                result.add(buffer.toString().trim());
                buffer = new StringBuilder();
            }
            buffer.append(sentence).append(" ");
        }
        if (buffer.length() > 0) result.add(buffer.toString().trim());
        return result;
    }

    private int parseIndex(String utteranceId) {
        try {
            return Integer.parseInt(utteranceId.replace("chunk_", ""));
        } catch (Exception e) {
            return 0;
        }
    }
}
